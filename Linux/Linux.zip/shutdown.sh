#!/bin/sh

process_id=`ps -ax | grep ethminer | grep -vw "grep" | grep -vw $$ | awk '{print $1}'`

if [ -z "$process_id" ];then
echo "+-------------------------------------------------------------+"
echo "Process ethminer Not Found  ...... Done"
echo "+-------------------------------------------------------------+"
exit
else
process_id_number=`ps -ax | grep ethminer | grep -vw "grep" | grep -vw $$ | awk '{print $1}'`

for i in ${process_id_number} ;do
kill -9 $i &> /dev/null
printf "%-40s %-s\n" "PID($i) ethminer Killed" "$(echo -ne "[ \\033[01;32m OK \\033[0m ]")"
done
sleep 2;
echo "+-------------------------------------------------------------+"
echo "Process ethminer Kill OK  ...... Done"
echo "+-------------------------------------------------------------+"
fi

