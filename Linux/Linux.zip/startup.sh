#!/bin/sh
./ethminer -v 3 -G -P stratum+tcp://jasss3941%2etest:x@asia1.ethereum.miningpoolhub.com:20535 -L 1 --cl-local-work 256 --HWMON 0 2>&1 | tee -a /usr/local/bin/miner.log &
