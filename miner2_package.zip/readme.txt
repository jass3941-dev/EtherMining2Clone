1. 옵션 중에 -L 2 옵션이 추가되었다.
   --> 추가된 부분은 DAG Item sync 을 위하여 

2. 명령줄 설명
   실행명령어  ethminer.exe -G -P stratum2+tcp://jasss3941%%2ewintest:x@asia1.ethereum.miningpoolhub.com:20535 --opencl-platform 1 --cl-local-work 256 -L 2 2>&1 | wtee logfile.txt
   추가된 부분 : -L 2  이것 실행중에  명기 필요
   바꿀부분 : jasss3941  --> 사용자 마플허 아이디로 변경
                wintest     --> 사용자가 정하는 마이너 명으로 변경 
                logfile.txt  --> 사용자가 원하는 로그파일 명으로 변경 
3. miner2_package.zip 파일을 임의의 디렉터리에 푼 후 그 디렉토리로 이동하여 startup.bat 파일을 수정 후 실행한다.
   실행 후 logfile.txt 가 생성되는지 확인한다. 







                        